let global = {
    OPENID: 'OPEN_ID',
    CURRENT_POINT: 'CURRENT_POINT'
}